import ar.com.dh.model.Empleado;
import ar.com.dh.model.Empresa;

import java.io.*;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {


        Empresa empresa = new Empresa();
        empresa.setRazonSocial("C2 S.A");
        empresa.setCuit("11");

        Empleado empleado1 = new Empleado("Pablo", "Vidal", "1", 1000);
        Empleado empleado2 = new Empleado("Vanina", "Simon", "2", 2000);
        Empleado empleado3 = new Empleado("Franco", "Gonzalo", "3", 3000);
        Empleado empleado4 = new Empleado("Elias", "nnn", "4", 4000);

        empresa.setListaEmpleados(Arrays.asList(empleado1, empleado2, empleado3, empleado4));

        FileOutputStream fileOutputStream = null;

        try {
            fileOutputStream = new FileOutputStream("empresa.txt");
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(empresa);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        // VOY A RECUPERAR EL ARCHIVO
        //PREPARAMOS LOS OBJETOS
        Empresa empresaRecuperada = null;
        FileInputStream fileInputStream = null;


        try {
            fileInputStream = new FileInputStream("empresa.txt");
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
            empresaRecuperada = (Empresa) objectInputStream.readObject();
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

        System.out.println(empresaRecuperada.getListaEmpleados());

        for (Empleado empleado : empresaRecuperada.getListaEmpleados()) {
            // System.out.println(empleado.getApellido() + "-" + empleado.getSueldo());
            System.out.println(empleado.toString());
        }

    }
}